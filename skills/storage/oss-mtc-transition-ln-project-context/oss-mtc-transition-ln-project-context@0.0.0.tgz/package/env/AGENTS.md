# AGENTS.md — 大屏（可视化分析）开发管理

> 本文件作为 **AI Agent / 团队成员** 开发 **大屏（可视化分析）** 相关功能时的入口说明。
> 范围聚焦：人员信息大屏、信访信息大屏、未来的「大数据综合展示」(`/visual/big-screen`) 等数据可视化模块。
> 其他业务（账号、组织、比对、统计报表等）不在本文件管理范围内，请参考对应 spec。

---

## 1. 项目速览

- 仓库：`oss-mtc-transition-ln`
- 技术栈：前端 React 19 + Ant Design 6 + Vite 8；后端 FastAPI + Kingbase
- 工具链：使用 `mise` 管理版本，参见仓库根 `mise.toml`
- 文档体系：`docs/specs/`（需求规格）、`docs/design/`（架构/契约/数据模型）、`docs/skills/`（开发规范）
- **会话启动**：AI Agent 新会话处理大屏相关任务时，须先加载 skill `oss-mtc-transition-ln-project-context` 建立私域上下文（task 管理、决策日志、私人备忘等）

---

## 2. 大屏开发范围

### 2.1 已存在 / 已规划的大屏模块

> 前端路由详见 技能 `oss-mtc-transition-ln-project-context` 下 `design/003-big-screen-routes.md`（大屏路由唯一权威记录点）。

| 模块             | 数据源（schema · 表）                                               | Spec                                                         | 现状                                                                           |
| ---------------- | ------------------------------------------------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------------------------ |
| 人员信息大屏     | `dw_basic_lc` · `stats_jdlk_persion_age_group` 等（§6 data-models） | `038-bigdata-personnel-display`                              | `/visual/big-screen?menu=personnel` ✅ 入口初始化完成（task-041）              |
| 辽宁信访大屏     | `dw_basic_lc` · `letter_screen_1`–`6`（§7 data-models）             | `039-bigdata-petition-display`（仅有 PM 输入，未生成五件套） | `/visual/big-screen?menu=petition` ✅ 入口初始化完成（task-041）               |
| 进京信访大屏     | `dw_basic_lc` · `letter_screen_*`                                   | `040-bigdata-beijing-petition-display`（同上）               | `/visual/big-screen?menu=beijingPetition` ⏭️ 入口占位（待用户提供布局参数）    |
| 信访数据比对大屏 | TBD                                                                 | `041-bigdata-petition-comparison-display`（同上）            | `/visual/big-screen?menu=petitionComparison` ⏭️ 入口占位（待用户提供布局参数） |
| 统计分析月报     | `dw_basic_lc` · `abi_*` / `analysis_report_file_info`               | `035-visual-monthly-statistics`                              | `/visual/stats/*`（不变）                                                      |

> 4 大屏路由采用 **单路由 + `?menu=xxx`（驼峰 key）切换**方案。详见 `.trae/skills/oss-mtc-transition-ln-project-context/design/003-big-screen-routes.md` §1 + `.trae/skills/oss-mtc-transition-ln-project-context/design/004-big-screen-architecture.md` §1.1。
>
> 入口初始化（task-041 完成）：`Visual` 壳 + `Header`（导航 + 中间大标题）+ `Background` + personnel 5 卡片 + petition 6 卡片布局；业务实现（图表 / API / 数据渲染）属后续 task-016 M3/M4。

### 2.2 涉及的关键文档

- 总体架构：[docs/design/architecture.md](docs/design/architecture.md)
- 系统总览：[docs/design/system-overview.md](docs/design/system-overview.md)（§2.2.2 菜单域）
- API 契约：[docs/design/api-contracts.md](docs/design/api-contracts.md)
- 数据模型：[docs/design/data-models.md](docs/design/data-models.md)（§6 人员大屏、§7 信访大屏、§11.1 遗留表）
- 技术栈：[docs/design/tech-stack.md](docs/design/tech-stack.md)
- 月报统计规格：[docs/specs/035-visual-monthly-statistics/spec.md](docs/specs/035-visual-monthly-statistics/spec.md)
- Kingbase 方言规范：[docs/skills/database/kingbase/coding.md](docs/skills/database/kingbase/coding.md)

> ⚠️ 添加新大屏模块前，先在 `docs/specs/` 下新建 spec（沿用 `NNN-<name>/spec.md` 五件套：`spec` / `plan` / `tasks` / `data-model-extensions` / `acceptance-tests`）。

---

## 3. 前端目录约定

约定位置（**目录与 PM 原文路由前缀对齐**，实际以仓库当前结构为准；不存在时请先确认）：

```
frontend/src/
├── pages/
│   ├── bigdata/
│   │   └── Personnel/            # 人员信息大屏（路由 /bigdata/personnel）
│   ├── dashboard/
│   │   ├── Petition/             # 辽宁信访大屏（路由 /dashboard/petition）
│   │   ├── PetitionBeijing/      # 进京信访大屏（路由 /dashboard/beijing-petition）
│   │   └── PetitionComparison/   # 信访比对大屏（路由 /dashboard/petition-comparison）
│   └── visual/
│       └── stats/                # 035 统计分析（月报，保持不变）
├── components/
│   └── big-screen/               # 通用大屏组件（数字翻牌、地图、轮播等，与路由前缀无关）
├── api/
│   └── visual/                   # 大屏相关 API 封装（前端 API 路径与路由不一致，按 API 契约）
└── hooks/
    └── visual/
```

**注意**：

- 本仓库 `frontend/src/` 下目前**尚未确认**有 `pages/bigdata/` 或 `pages/dashboard/` 目录。开始大屏开发时，**先核对**目录结构，避免在错误路径下新建文件。
- **页面目录路径 = 路由前缀**（PM 原文）；**API 目录**不受路由前缀影响，仍按业务命名。
- 详情见 memo R7（路由以 PM 文档为权威）。

---

## 4. 后端约定

- 路由：`backend/app/api/visual/`（大屏域端点）
- Service：`backend/app/services/visual/`
- Schema：`backend/app/schemas/visual/`
- 大屏查询 SQL：**不放 migration**，按 [architecture.md §6](docs/design/architecture.md) 约定放 `backend/app/services/visual/sql/` 或 `backend/app/repositories/sql/`，目录命名建议带 `kingbase` 标识。
- 端点前缀：与 comparison / visual 一致使用 `/api/visual/<sub-domain>`（**无** `/v1`）。
- 鉴权：菜单项粒度（详见系统总览 §2.4 与对应 spec）。

---

## 5. 大屏开发通用要点

1. **数据口径**：所有统计口径变更须同步更新 `docs/design/data-models.md` 中对应章节与 spec 中的「口径」条款。
2. **大屏只读**：大屏仅消费统计表（`stats_*` / `letter_screen_*` / `abi_*`）快照，不直接写明细库。
3. **导出/下载**：大屏如需导出，沿用 `035` 的 Excel 导出与 `Content-Disposition` 文件名规范。
4. **加载/空态/错误态**：必须实现；401 → `/login`，403 → `/403`，5xx 走契约统一错误体。
5. **图表方案**：已定选型 **ECharts 6.1.0 + echarts-for-react 3.0.6** + **@ant-design/plots 2.6.8**；（D1 已拍板，见 038/039 spec §0）；地图用 `EcMap` 共享组件；与设计资源对齐分辨率（建议 1920×1080 / 2K）。
6. **响应式**：大屏主要面向大屏展示端，PC 管理端的列表页另行布局。

---

## 6. 命名与代码风格

- 详见：[docs/skills/frontend/react/coding.md](docs/skills/frontend/react/coding.md)
- 大屏组件名使用 `PascalCase`，目录与文件名一致（如 `PersonnelAgeChart.tsx`）。
- 大屏页面入口文件建议命名：`index.tsx` + 子组件目录。

---

## 7. 开发流程（建议）

1. 新建/更新 spec（`docs/specs/NNN-<name>/`）
2. 在 `docs/design/data-models.md` 中确认/扩展统计表模型
3. 后端：定义 API + SQL + Service + Schema + 测试
4. 前端：API 封装 + 页面 + 组件 + 测试
5. 在对应 spec 的 `acceptance-tests.md` 中追加验收用例
6. 联调通过后更新本文件 §2.1 的表格，确保「新模块」可被未来 Agent 检索到

---

## 8. 禁止行为

- ❌ 不得修改本文件**以外**的 `docs/` 文档来引用本文件（`docs/` 禁止引用 `AGENTS.md`，详见 `.trae/rules/docs-no-private-refs.md`）
- ❌ 不要在本文件未涉及的目录中乱建文件（如 `packages/`、`backend/migrations/` 等）
- ❌ 不要把大屏查询 SQL 写进 Alembic migration
- ❌ 不要绕过菜单鉴权直接暴露大屏端点
- ❌ **不得编造不存在的文件路径、API 端点、数据库表 / 字段、配置项或依赖包**；引用前须实际 `Read` / `Grep` / `Glob` 验证其存在
- ❌ **不得虚构 docs 章节编号或内容**；引用 `docs/` 任何章节前须确认当前文件中确实有该编号
- ❌ **不得凭推测填充数据**（如编造表字段名、枚举值、SQL 结果）；未知数据须标「待验证」并记入 `plans/memo.md`
- ❌ **不得声称"已完成"未实际执行的操作**；task 状态须与实际产出物一致

---

## 10. 文档修改门禁（大屏可视化计划期间生效，2026-08-11）

> 本节约束本仓库所有 AI Agent / 团队成员对仓库文件的修改权限。

| 等级            | 范围                                                                   | 修改方式                                                    |
| --------------- | ---------------------------------------------------------------------- | ----------------------------------------------------------- |
| **L1 自由**     | `.trae/skills/oss-mtc-transition-ln-project-context/**`（个人/草稿区） | 当前会话可直接编辑                                          |
| **L2 计划授权** | 仓库根 `AGENTS.md`（含 `env/AGENTS.md` 硬链接镜像）                    | 必须走 `plans/roadmap-2026-08-11-big-screen.md` §6 提案审批 |
| **L3 严控**     | `docs/**/*.md`、`README.md`、`docs/specs/_template/**`                 | 必须走同上提案审批，且需 PM / 架构师会签                    |

- **L2 中 `AGENTS.md` 是规则的权威载体**：跨会话、跨阶段的硬规则必须沉淀至此，`.trae/skills/.../plans/` 仅作工作底稿。
- **L3 中 `\_template/**` 仅在 PM + 架构双签时可改\*\*；任何 spec 引用模板都假设模板稳定。
- **状态机**：`[ ] 提案` → `[ ] 审批中` → `[x] 执行并落行`。
- 任何 L2 / L3 改动前必须把变更条目放进对应 `plans/roadmap-*.md` §6 并勾选；勾选未走完视为违规。

### 10.1 task 文件生命周期

- task 文件位于 `.trae/skills/oss-mtc-transition-ln-project-context/plans/`
- 状态流转：`✅ 进入` → `🟡 进行中` → `✅ 完成`
- **完成的 task 必须移动到 `plans/done/` 子目录**，文件名保留原样（含日期与编号）
- `plans/` 根目录只保留"进入 / 进行中 / 暂停"状态的 task；`done/` 只保留已完成的
- 移动操作属于 L1（自由），不需要审批
- 移动后须同步更新 `plans/roadmap-*.md` §4 任务索引的状态列（如 `✅ 完成 → done/`）

---

## 9. 变更记录

| 日期       | 变更                                                                                   | 备注                        |
| ---------- | -------------------------------------------------------------------------------------- | --------------------------- |
| 2026-08-11 | 初始化 AGENTS.md，建立大屏开发管理入口                                                 | 初版                        |
| 2026-08-11 | 新增 §10 文档修改门禁（L1/L2/L3），与 `plans/roadmap-2026-08-11-big-screen.md` §6 联动 | R-AGENTS-L1L2L3             |
| 2026-08-11 | 新增 §10.1 task 文件生命周期（完成 task 移至 `plans/done/`）                           | R-AGENTS-TASK-DONE          |
| 2026-08-11 | §8 禁止行为新增 4 条反幻觉规则（不得编造路径/端点/表字段/章节编号/数据/操作状态）      | R-AGENTS-ANTI-HALLUCINATION |
| 2026-08-12 | §1 新增会话启动条目：AI Agent 须先加载 skill `oss-mtc-transition-ln-project-context`   | R-AGENTS-SKILL-AUTOLOAD     |
| 2026-08-13 | §2.1 路由权威源引用改为 `design/003-big-screen-routes.md`（原引用 project-meta.md §1） | R-AGENTS-ROUTE-REF          |
| 2026-08-17 | §5.5 图表方案改为已定选型（ECharts 6.1.0 + echarts-for-react 3.0.6，D1 已拍板）        | R-AGENTS-D1-CHART           |
