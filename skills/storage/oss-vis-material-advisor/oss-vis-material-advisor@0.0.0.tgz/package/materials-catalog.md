---
title: 物料维护清单（advisor 视角）
description: advisor 对全部 155 个有效物料的画像/文档化状态总览，按 18 个分类组织
version: 0.8
last_updated: 2026-10-29
---

# 物料维护清单（advisor 视角）

本清单覆盖 `src/packages/**/oss-material.json` 命中的全部 **155 个物料**，按 18 个分类组织，标注每个物料的：

-   复杂度（来自画像，缺失则为 `-`）
-   画像状态（✅ 已画像 / ⏳ 待画像）
-   自带 doc（📄 / —）
-   评级 + 分数 + 搭建成本（仅已画像）

> **分类原则**：每个物料只属于 1 个主分类（以 `oss-material.json.title` 为首要依据）。例如 "环形进度图" 类物料归入 [进度/加载](#进度--加载5)，"水平进度图" 归入 [进度/加载](#进度--加载5)，"进度条列表" 归入 [列表/排行](#列表--排行13)。
>
> **decoration-family 合并说明**：24 个 `decoration/border1-12` + `decoration/decoration1-12` 物料 schema 高度同源（仅颜色/路径不同），在 advisor 维度合并为 1 个 `profiles/decoration-family.json`（含 24 种变体枚举），不再单独画像。

## 状态说明

| 符号        | 含义                                         |
| ----------- | -------------------------------------------- |
| ✅ 已画像   | advisor 已生成 `profiles/{name}.json`        |
| ⏳ 待画像   | 物料存在但 advisor 尚未生成画像              |
| 📄 自带 doc | 物料自带 `doc/readme.md`（设计器侧边栏渲染） |
| 🟢 独立优秀 | 评级 A，6 维加权 ≥ 4.5                       |
| 🟡 组合可用 | 评级 B，3.5-4.5                              |
| 🔴 组合复杂 | 评级 C，2.5-3.5                              |
| ⚫ 不建议   | 评级 D，< 2.5                                |

## 总览

| 指标        | 数值         |
| ----------- | ------------ |
| 物料总数    | 155          |
| 已画像      | 132（85.2%） |
| 待画像      | 23（14.8%）  |
| 自带 doc    | 124（80.0%） |
| 🟢 独立优秀 | 25           |
| 🟡 组合可用 | 107          |
| 🔴 组合复杂 | 0            |
| ⚫ 不建议   | 0            |

> **剩余 23 个待画像物料**：`decoration/decoration1-11`（11 个）+ `decoration/border1-12`（12 个），全部为纯样式边框/装饰，无数据交互，画像意义低，已通过 `decoration-family.json` 合并覆盖。

## 按分类

### 容器 / 布局（8）

| 物料                            | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） |
| ------------------------------- | ------ | ---- | -------- | ----------- | ---- | --------------- |
| `dock-menu`                     | 高     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 15 min          |
| `ellipse-layout-indicator`      | 中     | ✅   | 📄       | 🟡 组合可用 | 3.3  | 15 min          |
| `free-layout-ind-progress`      | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 12 min          |
| `free-layout-indicator-group`   | 中     | ✅   | 📄       | 🟡 组合可用 | 3.6  | 15 min          |
| `free-layout-indicators-viewer` | 高     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 25 min          |
| `nine-grid`                     | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 8 min           |
| `scene-over-view-hlj`           | 高     | ✅   | 📄       | 🟡 组合可用 | 3.2  | 25 min          |
| `telescoping-board`             | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 12 min          |

> 已画像 8/8 ✅ 全部完成

### 文本 / 标签 / 标题（5）

| 物料                 | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） |
| -------------------- | ------ | ---- | -------- | ----------- | ---- | --------------- |
| `label-text`         | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.2  | 3 min           |
| `message-distribute` | 中     | ✅   | 📄       | 🟡 组合可用 | 3.4  | 10 min          |
| `normal-label`       | 中     | ✅   | 📄       | 🟢 独立优秀 | 4.0  | 2 min           |
| `textarea-label`     | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.3  | 5 min           |
| `description-table`  | 中     | ✅   | 📄       | 🟡 组合可用 | 3.3  | 8 min           |

> 已画像 5/5 ✅ 全部完成

### 数字 / 指标卡（7）

| 物料                     | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） |
| ------------------------ | ------ | ---- | -------- | ----------- | ---- | --------------- |
| `bidirectional-progress` | 中     | ✅   | 📄       | 🟢 独立优秀 | 4    | 10 min          |
| `business-quality`       | 中     | ✅   | 📄       | 🟡 组合可用 | 3.6  | 8 min           |
| `business-scale`         | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 6 min           |
| `digital-card`           | 中     | ✅   | 📄       | 🟡 组合可用 | 3.4  | 5 min           |
| `digital-flop`           | 中     | ✅   | 📄       | 🟢 独立优秀 | 4    | 8 min           |
| `indicator-display`      | 中     | ✅   | 📄       | 🟢 独立优秀 | 4    | 5 min           |
| `number-level-indicate`  | 中     | ✅   | 📄       | 🟡 组合可用 | 3.4  | 6 min           |

> 已画像 7/7 ✅ 全部完成

### 列表 / 排行（13）

| 物料                | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） |
| ------------------- | ------ | ---- | -------- | ----------- | ---- | --------------- |
| `carousel-list`     | 中     | ✅   | 📄       | 🟡 组合可用 | 3.7  | 12 min          |
| `carousel-notice`   | 中     | ✅   | 📄       | 🟡 组合可用 | 3.8  | 8 min           |
| `carousel-param`    | 中     | ✅   | 📄       | 🟡 组合可用 | 3.6  | 10 min          |
| `equip-list`        | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 10 min          |
| `hot-app-top5`      | 中     | ✅   | 📄       | 🟡 组合可用 | 3.9  | 10 min          |
| `monitor-topn-list` | 中     | ✅   | 📄       | 🟡 组合可用 | 3.7  | 12 min          |
| `progress-list`     | 中高   | ✅   | 📄       | 🟡 组合可用 | 3.7  | 10 min          |
| `top-rank`          | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.4  | 10 min          |
| `top-rank-shaanxi`  | 中     | ✅   | 📄       | 🟡 组合可用 | 3.4  | 10 min          |
| `topn-rank`         | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 12 min          |
| `topn-rank-one`     | 中     | ✅   | 📄       | 🟡 组合可用 | 3.7  | 10 min          |
| `tree-list`         | 中高   | ✅   | 📄       | 🟢 独立优秀 | 4.0  | 15 min          |
| `vertical-list`     | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.4  | 5 min           |

> 已画像 13/13 ✅ 全部完成

### 表格（10）

| 物料                 | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） |
| -------------------- | ------ | ---- | -------- | ----------- | ---- | --------------- |
| `drilldown-table`    | 高     | ✅   | 📄       | 🟡 组合可用 | 4.0  | 25 min          |
| `drilldown-table-2`  | 高     | ✅   | 📄       | 🟡 组合可用 | 3.8  | 22 min          |
| `expandable-table`   | 高     | ✅   | 📄       | 🟢 独立优秀 | 4.2  | 15 min          |
| `pagination-table`   | 高     | ✅   | 📄       | 🟢 独立优秀 | 4.2  | 15 min          |
| `table`              | 中     | ✅   | 📄       | 🟡 组合可用 | 3.8  | 3 min           |
| `table-detail`       | 高     | ✅   | 📄       | 🟢 独立优秀 | 4.0  | 12 min          |
| `table-fixedColumns` | 高     | ✅   | 📄       | 🟢 独立优秀 | 4.3  | 12 min          |
| `table-transpose`    | 中     | ✅   | 📄       | 🟡 组合可用 | 3.6  | 12 min          |
| `transfer-table`     | 中高   | ✅   | 📄       | 🟡 组合可用 | 3.7  | 15 min          |
| `alarm-window-card`  | 高     | ✅   | 📄       | 🟢 独立优秀 | 4.1  | 15 min          |

> 已画像 10/10 ✅ 全部完成

> **说明**：`alarm-window-card` 在原 `oss-material.json.title="订阅告警流水窗"` 中业务领域属于"告警"专项，但 groupId=5 在表格分类下，因此保留在表格清单内。详见 `profiles/alarm-window-card.json`。

### 表单 / 筛选（4）

| 物料                 | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） |
| -------------------- | ------ | ---- | -------- | ----------- | ---- | --------------- |
| `popover-check`      | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 8 min           |
| `popover-checkparam` | 中     | ✅   | 📄       | 🟡 组合可用 | 3.6  | 10 min          |
| `query-form-group`   | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 15 min          |
| `range-picker`       | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.4  | 5 min           |

> 已画像 4/4 ✅ 全部完成

### 按钮 / 操作（5）

| 物料                    | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） |
| ----------------------- | ------ | ---- | -------- | ----------- | ---- | --------------- |
| `custom-request-button` | 中     | ✅   | 📄       | 🟢 独立优秀 | 4.0  | 8 min           |
| `export-btn`            | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.2  | 6 min           |
| `ghost-btn`             | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.4  | 3 min           |
| `iframe`                | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.4  | 5 min           |
| `visual-iframe`         | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 8 min           |

> 已画像 5/5 ✅ 全部完成

### 轮播 / 公告（5）

| 物料                  | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） |
| --------------------- | ------ | ---- | -------- | ----------- | ---- | --------------- |
| `carousel-image-list` | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 10 min          |
| `tab-list`            | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 10 min          |
| `tab-list-2`          | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 12 min          |
| `tab-list-arc`        | 中高   | ✅   | 📄       | 🟡 组合可用 | 3.4  | 15 min          |
| `tab-list-static`     | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 8 min           |

> 已画像 5/5 ✅ 全部完成

### 图表（ECharts）（12）

| 物料                                | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） |
| ----------------------------------- | ------ | ---- | -------- | ----------- | ---- | --------------- |
| `circular-column`                   | 中高   | ✅   | 📄       | 🟢 独立优秀 | 4.0  | 5 min           |
| `cone-bar`                          | 中     | ✅   | 📄       | 🟡 组合可用 | 3.6  | 6 min           |
| `cone-bar-line`                     | 高     | ✅   | 📄       | 🟢 独立优秀 | 4.0  | 8 min           |
| `cone-single-bar`                   | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 5 min           |
| `dual-axes-chart`                   | 高     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 20 min          |
| `echarts-bar`                       | 中     | ✅   | 📄       | 🟢 独立优秀 | 4.2  | 6 min           |
| `echarts-gauge`                     | 极高   | ✅   | 📄       | 🟢 独立优秀 | 4.0  | 30 min          |
| `echarts-liquid`                    | 中     | ✅   | 📄       | 🟡 组合可用 | 3.4  | 5 min           |
| `echarts-map`                       | 高     | ✅   | 📄       | 🟡 组合可用 | 3.7  | 51 min          |
| `echarts-multi-variable-area-chart` | 极高   | ✅   | 📄       | 🟢 独立优秀 | 4.0  | 15 min          |
| `echarts-pie`                       | 中     | ✅   | 📄       | 🟢 独立优秀 | 4.3  | 7 min           |
| `ind-list-echarts-gauge`            | 极高   | ✅   | 📄       | 🟢 独立优秀 | 4.0  | 20 min          |

> 已画像 12/12 ✅ 全部完成

### 图表（oss-chart-plots）（23）

| 物料                                     | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） |
| ---------------------------------------- | ------ | ---- | -------- | ----------- | ---- | --------------- |
| `oss-chart-plots/plots/area`             | 中     | ✅   | —        | 🟡 组合可用 | 3.6  | 6 min           |
| `oss-chart-plots/plots/bar`              | 中     | ✅   | —        | 🟡 组合可用 | 3.7  | 5 min           |
| `oss-chart-plots/plots/base-area`        | 中     | ✅   | 📄       | 🟡 组合可用 | 3.6  | 7 min           |
| `oss-chart-plots/plots/base-scatter`     | 中     | ✅   | 📄       | 🟡 组合可用 | 3.6  | 8 min           |
| `oss-chart-plots/plots/column`           | 中     | ✅   | 📄       | 🟢 独立优秀 | 4.0  | 5 min           |
| `oss-chart-plots/plots/double-gauge`     | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 8 min           |
| `oss-chart-plots/plots/dual-axes`        | 中高   | ✅   | 📄       | 🟡 组合可用 | 3.5  | 10 min          |
| `oss-chart-plots/plots/dual-column-line` | 高     | ✅   | 📄       | 🟢 独立优秀 | 4.0  | 15 min          |
| `oss-chart-plots/plots/funnel`           | 中     | ✅   | —        | 🟡 组合可用 | 3.5  | 6 min           |
| `oss-chart-plots/plots/gauge`            | 中     | ✅   | —        | 🟡 组合可用 | 3.4  | 5 min           |
| `oss-chart-plots/plots/histogram`        | 中     | ✅   | —        | 🟡 组合可用 | 3.5  | 5 min           |
| `oss-chart-plots/plots/line`             | 中     | ✅   | —        | 🟡 组合可用 | 3.6  | 5 min           |
| `oss-chart-plots/plots/liquid`           | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 5 min           |
| `oss-chart-plots/plots/pie`              | 中     | ✅   | —        | 🟢 独立优秀 | 4.0  | 5 min           |
| `oss-chart-plots/plots/radar`            | 中     | ✅   | —        | 🟡 组合可用 | 3.5  | 7 min           |
| `oss-chart-plots/plots/rose`             | 中     | ✅   | —        | 🟡 组合可用 | 3.6  | 5 min           |
| `oss-chart-plots/plots/sankey`           | 中     | ✅   | 📄       | 🟡 组合可用 | 3.6  | 7 min           |
| `oss-chart-plots/plots/series-area`      | 高     | ✅   | 📄       | 🟢 独立优秀 | 4.0  | 18 min          |
| `oss-chart-plots/plots/series-bar`       | 中     | ✅   | —        | 🟡 组合可用 | 3.5  | 7 min           |
| `oss-chart-plots/plots/series-column`    | 中高   | ✅   | —        | 🟢 独立优秀 | 4.0  | 12 min          |
| `oss-chart-plots/plots/stack-bar`        | 中     | ✅   | —        | 🟡 组合可用 | 3.5  | 7 min           |
| `oss-chart-plots/plots/stack-column`     | 中高   | ✅   | 📄       | 🟢 独立优秀 | 4.0  | 10 min          |
| `oss-chart-plots/plots/word-cloud`       | 中     | ✅   | —        | 🟡 组合可用 | 3.4  | 5 min           |

> 已画像 23/23 ✅ 全部完成

### 地图（8）

| 物料                     | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） |
| ------------------------ | ------ | ---- | -------- | ----------- | ---- | --------------- |
| `baidu-map`              | 中     | ✅   | 📄       | 🟡 组合可用 | 3.6  | 30 min          |
| `baidu-map-unicom`       | 中     | ✅   | 📄       | 🟡 组合可用 | 3.2  | 30 min          |
| `geo-3d-map`             | 高     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 120 min         |
| `geo-cascader`           | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 15 min          |
| `oss-chart-classify-map` | 高     | ✅   | 📄       | 🟡 组合可用 | 3.4  | 90 min          |
| `oss-chart-fly-line-map` | 中高   | ✅   | 📄       | 🟡 组合可用 | 3.5  | 60 min          |
| `oss-chart-map`          | 高     | ✅   | 📄       | 🟡 组合可用 | 3.6  | 90 min          |
| `oss-gis`                | 高     | ✅   | 📄       | 🟡 组合可用 | 3.7  | 90 min          |

> 已画像 8/8 ✅ 全部完成

### 3D / 拓扑（4）

| 物料                       | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） |
| -------------------------- | ------ | ---- | -------- | ----------- | ---- | --------------- |
| `model-3d/smart-warehouse` | 高     | ✅   | 📄       | 🟡 组合可用 | 3.4  | 60 min          |
| `twaver-topo`              | 中高   | ✅   | 📄       | 🟡 组合可用 | 3.7  | 30 min          |
| `virtual-3d-column`        | 高     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 20 min          |
| `virtual-3d-column-normal` | 高     | ✅   | 📄       | 🟡 组合可用 | 3.3  | 20 min          |

> 已画像 4/4 ✅ 全部完成

### 时钟 / 动画（5）

| 物料               | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） |
| ------------------ | ------ | ---- | -------- | ----------- | ---- | --------------- |
| `levitated-sphere` | 中     | ✅   | 📄       | 🟡 组合可用 | 3.6  | 25 min          |
| `normal-clock`     | 简单   | ✅   | 📄       | 🟢 独立优秀 | 4.0  | 5 min           |
| `path-animation`   | 中     | ✅   | 📄       | 🟡 组合可用 | 3.0  | 15 min          |
| `svg-render`       | 中     | ✅   | 📄       | 🟡 组合可用 | 3.0  | 20 min          |
| `warning-board`    | 中     | ✅   | 📄       | 🟡 组合可用 | 3.6  | 15 min          |

> 已画像 5/5 ✅ 全部完成

### 媒体 / 播放（3）

| 物料              | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） |
| ----------------- | ------ | ---- | -------- | ----------- | ---- | --------------- |
| `single-image`    | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.5  | 2 min           |
| `video-playback`  | 中     | ✅   | 📄       | 🟡 组合可用 | 3.0  | 8 min           |
| `weather-display` | 中     | ✅   | 📄       | 🟡 组合可用 | 3.3  | 10 min          |

> 已画像 3/3 ✅ 全部完成

### 进度 / 加载（5）

| 物料                      | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） |
| ------------------------- | ------ | ---- | -------- | ----------- | ---- | --------------- |
| `circular-progress`       | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 8 min           |
| `circular-progress-group` | 中     | ✅   | 📄       | 🟡 组合可用 | 3.6  | 12 min          |
| `normal-process`          | 中     | ✅   | 📄       | 🟡 组合可用 | 3.3  | 10 min          |
| `pagination-display`      | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.3  | 8 min           |
| `progress-list-bar`       | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 10 min          |

> 已画像 5/5 ✅ 全部完成

### 状态 / 标签（4）

| 物料               | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） |
| ------------------ | ------ | ---- | -------- | ----------- | ---- | --------------- |
| `stats-indi`       | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.5  | 5 min           |
| `stats-indi-grid`  | 中     | ✅   | 📄       | 🟡 组合可用 | 3.3  | 10 min          |
| `stats-indi-group` | 中     | ✅   | 📄       | 🟡 组合可用 | 3.3  | 12 min          |
| `status-display`   | 中     | ✅   | 📄       | 🟡 组合可用 | 3.4  | 8 min           |

> 已画像 4/4 ✅ 全部完成

### 边框 / 装饰（27）

> **合并画像**：`decoration/border1-12`（12 个）+ `decoration/decoration1-12`（12 个）共 24 个物料 schema 高度同源，已合并为单一画像 `decoration-family.json`（24 个变体枚举）。其余 3 个独立物料（hexagon / flash-point / common-container）单独画像。

| 物料                          | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） | 说明                     |
| ----------------------------- | ------ | ---- | -------- | ----------- | ---- | --------------- | ------------------------ |
| `decoration/border1`          | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/border2`          | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/border3`          | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/border4`          | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/border5`          | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/border6`          | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/border7`          | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/border8`          | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/border9`          | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/border10`         | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/border11`         | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/border12`         | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/decoration1`      | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/decoration2`      | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/decoration3`      | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/decoration4`      | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/decoration5`      | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/decoration6`      | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/decoration7`      | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/decoration8`      | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/decoration9`      | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/decoration10`     | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/decoration11`     | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/decoration12`     | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.0  | 2 min           | 合并入 decoration-family |
| `decoration/hexagon`          | 简单   | ✅   | —        | 🟡 组合可用 | 3.0  | 5 min           | 独立画像                 |
| `decoration/flash-point`      | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.0  | 5 min           | 独立画像                 |
| `decoration/common-container` | 中     | ✅   | 📄       | 🟡 组合可用 | 3.4  | 5 min           | 独立画像                 |

> 已画像 27/27 ✅ 全部完成（24 个合并为 decoration-family + 3 个独立画像）

### 其他（7）

| 物料                  | 复杂度 | 画像 | 自带 doc | 评级        | 分数 | 搭建（minimal） |
| --------------------- | ------ | ---- | -------- | ----------- | ---- | --------------- |
| `render-stage-loader` | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.3  | 5 min           |
| `zone-setting`        | 中     | ✅   | 📄       | 🟡 组合可用 | 3.3  | 15 min          |
| `area-business-vol`   | 中高   | ✅   | 📄       | 🟡 组合可用 | 3.2  | 20 min          |
| `echarts-line-dual-x` | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 10 min          |
| `echarts-3d-pie`      | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 15 min          |
| `top-n`               | 中     | ✅   | 📄       | 🟡 组合可用 | 3.5  | 10 min          |
| `params-trigger`      | 简单   | ✅   | 📄       | 🟡 组合可用 | 3.7  | 5 min           |

> 已画像 7/7 ✅ 全部完成

## 推进建议

当前覆盖率 **85.2%**（132/155），后续批次建议：

1. **第一批**（已做，11 个）：8 个有 5+1 文档物料 + 3 个高频（echarts-map/table/top-rank）
2. **第二批**（已完成，9 个）：表格全部完成（drilldown-table / drilldown-table-2 / expandable-table / pagination-table / table-detail / table-fixedColumns / table-transpose / transfer-table / alarm-window-card；table 在第一批）
3. **第三批**（已完成，12 个）：列表/排行全做（carousel-list / carousel-notice / carousel-param / equip-list / hot-app-top5 / monitor-topn-list / progress-list / top-rank-shaanxi / topn-rank / topn-rank-one / tree-list / vertical-list；top-rank 在第一批）
4. **第四批**（已完成，9 个）：图表 ECharts 剩余全做（circular-column / cone-bar / cone-bar-line / cone-single-bar / dual-axes-chart / echarts-gauge / echarts-liquid / echarts-multi-variable-area-chart / ind-list-echarts-gauge）
5. **第五批**（已完成，23 个）：oss-chart-plots 系列全做（area / bar / base-area / base-scatter / column / double-gauge / dual-axes / dual-column-line / funnel / gauge / histogram / line / liquid / pie / radar / rose / sankey / series-area / series-bar / series-column / stack-bar / stack-column / word-cloud）
6. **第六批**（已完成，18 个）：数字/指标卡（4 个）+ 容器/布局（6 个）+ 地图（8 个）全部完成
7. **第七批**（已完成，20 个）：3D/拓扑（6）+ 时钟/动画（4）+ 媒体/播放（3）+ 进度/加载（5）+ 其他（2）= 20 个
8. **第八批**（已完成，17 个）：状态/标签（4）+ 表单/筛选（4）+ 按钮/操作（5）+ 文本/标签/标题（4）= 17 个
9. **第九批**（已完成，5 个）：轮播/公告
10. **第十批**（已完成，7 个）：其他（3）+ 装饰汇总（4 = decoration-family 合并 24 + hexagon + flash-point + common-container）= 7 个
11. **累计**：10 批画像 + 1 个补录画像（params-trigger），共 **132 个画像 / 155 物料，覆盖率 85.2%**
12. **剩余 23 个**：border1-12 + decoration1-11 全部为纯样式边框/装饰，已通过 `decoration-family.json` 合并覆盖，无需单独画像

## 与 development-assistant 清单的关系

-   本清单的**物料分类与名称**与 `oss-vis-material-development-assistant/materials/README.md` 保持一致（单一真相）
-   本清单**新增画像状态、评级、分数、搭建成本** 4 列（advisor 独有）
-   两份清单互为补充，**没有重复维护负担**
