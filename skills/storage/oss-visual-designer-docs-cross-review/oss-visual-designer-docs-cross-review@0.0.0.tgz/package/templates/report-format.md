# 报告格式模板

> 本文件是 oss-visual-designer-docs-cross-review skill 的报告格式模板。
> reviewer 在产出 review 报告时按本文件结构填充内容，每个 `{xxx}` 占位符替换为真实数据。
> 字段含义与 SKILL.md §8 对应。
>
> 与通用版（`trae-docs-cross-review/templates/report-format.md`）的区别：
>   - Review Mode 固定为 `repo-backed`（oss 项目版默认，无 doc-only / mixed 切换）
>   - 项目特化检查固定是 oss 自己的 §9 Project-Specific Config
>   - 不存在"是否加载了 `<project>-docs-cross-review` skill" 这一字段

---

# {被 review 文档名} 交叉 review

> Reviewer：oss-visual-designer-docs-cross-review skill（三视角 + 对抗式交叉验证）
> Review 日期：{YYYY-MM-DD}
> Review 对象：`{文档路径}`
> Review Mode：repo-backed
> 项目特化检查：已应用 §9 Project-Specific Config
> 事实依据：{列出 subagent 用的 Grep / Read 证据来源}

---

## 0. 总评

**评级**：{A / B+ / B / C}（{一句话总评}）

**整体判断**：{2-3 句话概述文档质量、主要优点、主要问题}

按漏洞严重程度分 3 档列出（高 / 中 / 低），每条带具体修复建议。

---

## 1. 必须修复（高优先级）

### 1.1 [高] {问题标题}

- **事实**：{subagent 发现的问题，带仓库证据}
- **风险**：{如果不修会怎样}
- **修复建议**：{具体怎么改}
- **验证视角**：{A 事实核查 / B 架构逻辑 / C 盲区排查 / 交叉验证}

---

## 2. 建议优化（中优先级）

（同上格式）

---

## 3. 可选改进（低优先级）

（同上格式）

---

## 4. 关键事实补充（独立验证）

{列出 subagent 独立验证的事实，与文档陈述对照}

---

## 5. 总结

### 5.1 必须修

### 5.2 建议优化

### 5.3 可选改进

### 5.4 可以进入下一阶段吗？

**{可以 / 不可以}**，理由：{...}