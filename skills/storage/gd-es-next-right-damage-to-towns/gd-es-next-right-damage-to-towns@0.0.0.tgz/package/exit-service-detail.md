# ExitServiceDetail 退服统计弹窗

## 概述

退服统计弹窗（`ExitServiceDetail.tsx`）是「乡镇受损」模块的详情弹窗，通过点击模块标题栏的「退服统计」按钮打开。支持物理退服/逻辑退服切换和多层级下钻。

- **组件文件**：`apps/main/app/components/right/network-compact/damage-to-towns/ExitServiceDetail.tsx`
- **样式文件**：`apps/main/app/components/right/network-compact/damage-to-towns/index.css`
- **弹窗容器**：`index.tsx` 中 `StyledDraggableModal`（受 `state.disabledDraggable` 控制拖拽）

---

## 功能特性

| 特性             | 说明                                                               |
| ---------------- | ------------------------------------------------------------------ |
| **数据类型切换** | 按钮组在物理退服 / 逻辑退服间切换，样式与 Part.Middle 一致         |
| **多层级下钻**   | 省级 → 地市 → 区县 → 乡镇，通过 `state.drillDownPath` 维护下钻栈   |
| **动态列**       | 从 `environment.json` 读取列配置，`StyledTable` 渲染               |
| **智能排序**     | `sortable: true` 启用，数字优先，字符串走 `localeCompare("zh-CN")` |
| **格式化单元格** | `FormattedCell` 组件，支持 `tooltipTemplate` 和 `formatCellText`   |
| **返回上一级**   | 非顶层时显示「返回上一级」按钮，逐级回退                           |

---

## 按钮组实现

`ServiceType` 枚举定义在 [Context.tsx](apps/main/app/components/right/network-compact/damage-to-towns/Context.tsx) 中，`ExitServiceDetail` 和 `Part.Middle` 共用：

```typescript
// Context.tsx
export enum ServiceType {
    Physical = "physical",
    Logical = "logical",
}
```

```tsx
// ExitServiceDetail.tsx
import { ServiceType } from "./Context";

const btns = [
    { label: "物理退服", value: ServiceType.Physical },
    { label: "逻辑退服", value: ServiceType.Logical },
];

<div className="btns">
    {btns.map((item) => (
        <div
            className={cx("btn", { active: state.exitServiceType === item.value })}
            key={item.value}
            onClick={() => setState({ exitServiceType: item.value })}
        >
            {item.label}
        </div>
    ))}
</div>;
```

外层使用 `exit-service-detail-modal` 类名样式隔离，按钮样式定义在 `index.css`。

---

## 下钻参数构建

### buildRequestParams() 各层级映射

| 场景             | 请求目标层级 | zoneName      | zoneLevel              | parentName    | regionName    |
| ---------------- | ------------ | ------------- | ---------------------- | ------------- | ------------- |
| 初始（无下钻）   | province     | "广东省"      | ZoneLevelEnum.province | "-1"          | "-1"          |
| 点击 province 行 | region       | 该行 `region` | ZoneLevelEnum.region   | "-1"          | "-1"          |
| 点击 region 行   | city         | 该行 `city`   | ZoneLevelEnum.city     | 该行 `region` | "-1"          |
| 点击 city 行     | town         | 该行 `town`   | ZoneLevelEnum.town     | 该行 `city`   | 该行 `region` |

### dataTime 处理

- 下钻路径最后一条有 `dataTime` → 复用
- 否则使用 `dayjs().format("YYYY-MM-DD HH:mm:ss")`

---

## 行点击与下钻控制

```typescript
const handleRowClick = (record: any) => {
    // zoneLevel === city 时终止下钻（可在此扩展乡镇详情）
    if (record.zoneLevel === ZoneLevelEnum.city) {
        return;
    }
    const newDrillDownPath = [...state.drillDownPath, record];
    setState({ drillDownPath: newDrillDownPath });
};
```

---

## 弹窗拖拽控制

`index.tsx` 中通过 `state.disabledDraggable` 控制：

- `ExitServiceDetail` 顶部数据时间 + 按钮区域 `onMouseOver` → 允许拖拽
- `onMouseOut` → 禁止拖拽

---

## 相关 API

| 接口                                     | viewItemId                              | 用途         |
| ---------------------------------------- | --------------------------------------- | ------------ |
| `getTownshipOutOfServiceCountPhysicsApi` | `township-out-of-service-count-physics` | 物理退服数据 |
| `getTownshipOutOfServiceCountLogicApi`   | `township-out-of-service-count-logic`   | 逻辑退服数据 |

详细请求/响应结构见 [api-reference.md](./api-reference.md#5-弹窗物理退服)。

---

## 环境配置

列配置路径：`gd-emergency-support.modules.damage-to-towns.detailModal.{type}.columns.{zoneLevel}`

详细配置规范见 [config-reference.md](./config-reference.md)。

---

## 依赖

- React + TypeScript
- antd（ConfigProvider、Tooltip、Button）
- ahooks（useSetState、useRequest）
- dayjs
- 项目内部：StyledTable
- 工具函数：getEnvironment、formatString、cx

---

## 版本信息

| 字段           | 值                                                                                                                                          |
| -------------- | ------------------------------------------------------------------------------------------------------------------------------------------- |
| **Skill ID**   | `gd-es-next-right-damage-to-towns`                                                                                                          |
| **当前版本**   | `1.1.0`                                                                                                                                     |
| **最后更新**   | `2026-06-16`                                                                                                                                |
| **维护者**     | Emergency Support Team                                                                                                                      |
| **所属 Skill** | `gd-es-next-right-damage-to-towns`（[SKILL.md](./SKILL.md)）                                                                                |
| **组件文件**   | `apps/main/app/components/right/network-compact/damage-to-towns/ExitServiceDetail.tsx`                                                      |
| **容器**       | `index.tsx` 中 `StyledDraggableModal`（受 `state.disabledDraggable` 控制）                                                                  |
| **关联接口**   | `getTownshipOutOfServiceCountPhysicsApi` / `getTownshipOutOfServiceCountLogicApi`（详见 [api-reference.md](./api-reference.md)）            |
| **关联配置**   | `gd-emergency-support.modules.damage-to-towns.detailModal.{physical\|logic}.columns.*`（详见 [config-reference.md](./config-reference.md)） |

## 版本历史

| 版本    | 日期         | 变更摘要                                                                                                      |
| ------- | ------------ | ------------------------------------------------------------------------------------------------------------- |
| `1.1.0` | `2026-06-16` | 补充 frontmatter 关联元数据；明确"按钮组 / 下钻参数 / 拖拽控制"三段式架构；强化与主 Skill 及子 Skill 的引用链 |
| `1.0.0` | `2026-06-02` | 初版发布：覆盖按钮组、buildRequestParams 映射、行点击控制、拖拽控制、相关 API、环境配置、依赖                 |

## 适用范围

- ✅ **适用**：调整物理/逻辑退服按钮顺序、调整下钻终止条件（`zoneLevel === city`）、调整按钮样式
- ✅ **适用**：调整 `buildRequestParams()` 层级映射关系
- ✅ **适用**：调整 `FormattedCell` 组件（tooltip/formatCellText）
- ✅ **适用**：调整拖拽触发区域与 `disabledDraggable` 切换逻辑
- ⚠️ **谨慎**：修改 `zoneLevel === ZoneLevelEnum.city` 终止下钻的判断（影响所有下钻栈）
- ❌ **不适用**：弹窗外部容器（`StyledDraggableModal`）的全局样式修改（应在 `StyledDraggableModal` 自身处处理）
