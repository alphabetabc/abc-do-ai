---
name: gd-es-next-right-damage-to-towns
title: 右屏乡镇受损模块维护技能
description: 维护右屏「乡镇受损」(damage-to-towns) 模块，包含 Left/Middle/Right 三栏表格、区域统计、退服统计弹窗（ExitServiceDetail）、物理/逻辑切换与多级下钻。Invoke when 修改、修复或优化 damage-to-towns 模块及其子组件、ExitServiceDetail 弹窗、相关 API、配置、样式时。
version: 1.1.0
author: Emergency Support Team
tags:
    - network
    - maintenance
    - component
    - emergency-support
    - damage-to-towns
    - right-panel
last_updated: 2026-06-16
---

# damage-to-towns 模块维护 Skill

## 概述

维护应急支撑大屏右屏「乡镇受损」模块，呈现广东省乡镇级网络退服与传输路由中断情况。

- **模块路径**：`apps/main/app/components/right/network-compact/damage-to-towns/`
- **接口文件**：`apps/main/request/right.ts`
- **环境配置**：`apps/main/public/config/environment.json`
- **区域枚举**：`apps/main/app/components/enum`（`ZoneLevelEnum`）

---

## 文件一览

| 文件                       | 职责                                                                                           |
| -------------------------- | ---------------------------------------------------------------------------------------------- |
| `index.tsx`                | 模块入口；组装三栏、挂载 Provider、承载详情弹窗、定义 onCellClick 派发 GIS 打点                |
| `Context.tsx`              | Provider/useQueryContext 数据中心；构建请求参数、拉取三个子表数据；定义共享 `ServiceType` 枚举 |
| `Part.Left.tsx`            | 左栏：蓝/黄/红三色旗帜统计 + 区域汇总表                                                        |
| `Part.Left.Table.tsx`      | 左栏区域汇总表 LeftTable 与 useLeftTable Hook                                                  |
| `Part.Middle.tsx`          | 中栏：乡镇退服表                                                                               |
| `Part.Middle.Settings.tsx` | 中栏列定义、btns、useMiddleTable Hook                                                          |
| `Part.Right.tsx`           | 右栏：乡镇出局路由表，列定义内置颜色映射、GIS 打点交互                                         |
| `Part.Right.Table.tsx`     | useRightTable Hook                                                                             |
| `ExitServiceDetail.tsx`    | 退服统计详情弹窗：物理/逻辑切换、多级下钻、动态列、排序、tooltip                               |
| `index.css`                | 模块整体布局与表格暗黑样式                                                                     |

---

## 架构与数据流

```
                    ┌─────────────────────────────────────┐
                    │            index.tsx                 │
                    │  Provider(region, selectedRecord)    │
                    │  onCellClick → dispatch GIS + record │
                    │  StyledModal → ExitServiceDetail     │
                    └──────────┬──────────────────────────┘
                               │
                    ┌──────────▼──────────────────────────┐
                    │          Context.tsx                  │
                    │  ┌─ currentRegionParams               │
                    │  │   (左栏 + 小旗子)                   │
                    │  ├─ middleRightRegionParams            │
                    │  │   (中栏 + 右栏)                     │
                    │  ├─ getTownDamageStatisticsApi → 旗子  │
                    │  ├─ useLeftTable() → 左栏表格          │
                    │  ├─ useMiddleTable() → 中栏表格         │
                    │  └─ useRightTable() → 右栏表格          │
                    └──────────────────────────────────────┘
                               │
         ┌─────────────────────┼─────────────────────┐
         ▼                     ▼                     ▼
   Part.Left.tsx         Part.Middle.tsx        Part.Right.tsx
   ┌──────────┐          ┌─────────────┐       ┌──────────────┐
   │旗帜统计    │          │ 乡镇退服表    │       │ 乡镇出局路由   │
   │区域汇总表  │          │ (物理站)     │       │ (传输中断)    │
   └──────────┘          └─────────────┘       └──────────────┘
         │                     │                     │
         │    leftSelectedFlag 过滤 severity/alarmType │
         └─────────────────────┼─────────────────────┘
                               │
                    ┌──────────▼──────────────────────────┐
                    │       ExitServiceDetail.tsx          │
                    │  退服统计弹窗（点击"退服统计"打开）    │
                    │  ┌─ 物理/逻辑切换 (btns)             │
                    │  ├─ 多级下钻 (drillDownPath)          │
                    │  ├─ 动态列 (environment.json)         │
                    │  └─ 排序 / tooltip / 格式化单元格     │
                    └──────────────────────────────────────┘
```

### 关键联动机制

- **左栏旗帜过滤**：点击旗帜 → `setLeftFlag` → 中/右两栏按 `severity`/`alarmType` 过滤
- **GIS 联动**：行 GIS 图标点击 → `onCellClick` → `dispatch("sectionRight:damageToTownsGisPin")`
- **选中记录**：`dispatch("sectionRight:damageToTownsSelectedRecord")` 同步选中行
- **区域参数**：`currentRegionParams` 在 city/town 层级自动回退到所属 region 请求
- **轮询**：`useEnvironment("gd-emergency-support.modules.damage-to-towns.request.interval")`，默认 300 秒

---

## 关键交互机制详解

### 1. `onCellClick` 三表派发 payload 结构

`index.tsx` 的 `onCellClick` 根据 `info.table` 走三条分支构建 GIS 派发参数，差异如下表：

| 字段              | `middleTable`        | `rightTable`          | `exitServiceDetailModal` |
| ----------------- | -------------------- | --------------------- | ------------------------ |
| `zoneName`        | `record.cityName`    | `record.regionName`   | `record.cityName`        |
| `townName`        | `record.townName`    | `record.regionName`   | `record.townName`        |
| `townId`          | `record.townId`      | `undefined`           | `record.townId`          |
| `regionName`      | `record.regionName`  | `record.parentRegion` | `record.regionName`      |
| `cityName`        | `record.cityName`    | `record.cityName`     | `record.cityName`        |
| `alarmType`       | **`info.tableType`** | `record.alarmType`    | **`info.tableType`**     |
| `scanTime`        | `record.scanTime`    | —                     | —                        |
| `dataTime`        | —                    | `record.dataTime`     | `record.dataTime`        |
| `isTownExitRoute` | `false`              | **`true`**            | `false`                  |
| `zoneLevel`       | 固定 `"3"`           | 固定 `"3"`            | 固定 `"3"`               |
| `sceneType`       | `"township"`         | `"township"`          | `"township"`             |
| `isTownship`      | `true`               | `true`                | `true`                   |
| `selected`        | `info.selected`      | `info.selected`       | `info.selected`          |

> **关键点**：
>
> - `rightTable`（乡镇出局路由）特殊地设置 `isTownExitRoute = true`，GIS 接收方可据此区分来源表
> - `middleTable` 与 `exitServiceDetailModal` 的 `alarmType` 取 `info.tableType`（即物理/逻辑标识），其他表取 `record.alarmType`（业务告警类型）
> - `scanTime` 与 `dataTime` 是不同语义：扫描时间 vs 数据时间，分表使用不可混用
> - `zoneLevel` 固定 `"3"` 是与后端约定的"乡镇级"标识

### 2. 旗帜过滤双映射规则

左栏点击旗帜 → `setLeftFlag(color: 'red' | 'yellow' | 'blue')` 后，中/右两栏使用**不同的过滤字段**：

| 表格 | 过滤逻辑                                             | 文件                 |
| ---- | ---------------------------------------------------- | -------------------- |
| 中栏 | `d.severity === leftSelectedFlag`                    | `Part.Middle.tsx:30` |
| 右栏 | `d.alarmType === AlarmLevelString[leftSelectedFlag]` | `Part.Right.tsx:82`  |

**`AlarmLevelString` 映射表**（`Context.tsx:23-27`）：

```typescript
const AlarmLevelString = {
    [ColorLevelString.Red]: "乡镇全阻",
    [ColorLevelString.Yellow]: "乡镇双断",
    [ColorLevelString.Blue]: "乡镇单断",
};
```

> **维护注意**：
>
> - 中栏 `severity` 字段值是 `red/yellow/blue`（与 `ColorLevelString` 同名）
> - 右栏 `alarmType` 字段值是中文业务标签（乡镇全阻/双断/单断）
> - **新增颜色枚举时，必须同步更新 `AlarmLevelString`**，否则右栏过滤失效
> - 旗帜点击同一颜色会切换"激活/取消激活"（`isActive ? null : item.flag`）

### 3. `currentRegionParams` 回退规则

`Context.tsx:80-141` 的 `currentRegionParams` 用于左栏（旗帜 + 区域汇总表）的请求。**与典型"层级递进"不同**，city/town 层级会强制回退到所属 region 重新请求：

| 当前 `currentZone.zoneLevel` | 请求时的 `zoneName`          | 请求时的 `zoneLevel`       | 备注         |
| ---------------------------- | ---------------------------- | -------------------------- | ------------ |
| `province`                   | `currentZone.zoneName`       | `currentZone.zoneLevel`    | 透传         |
| `city`                       | **`currentZone.regionName`** | **`ZoneLevelEnum.region`** | **强制回退** |
| `town`                       | **`currentZone.regionName`** | **`ZoneLevelEnum.region`** | **强制回退** |

> **关键点**：
>
> - 进入 city/town 后，左栏依然展示"所属地市"的整体数据，而非"当前地市"
> - 设计意图：左栏的"小旗子 + 区域汇总表"是宏观视角，不随下钻细化
> - `parentName` / `regionName` 在非 province 层级时仍为 `"-1"`，由 `zoneLevel` 调整代替层级递进
> - `dataTime` 使用 getter 每次请求实时取当前时间（`dayjs().format("YYYY-MM-DD HH:mm:ss")`）

### 4. `dataTime` 同步链路

中/右两栏表格的 `dataTime` **不是各自取当前时间**，而是**以左栏区域汇总表的第一条 `dataTime` 为基准**：

```
左栏 useLeftTable() 拉取 getTownDamageStatisticsZoneApi
        │
        ▼
leftDataTime = leftState.dataSource[0].dataTime
        │   (Context.tsx:144)
        ▼
传给 useMiddleTable / useRightTable 作为参数
        │
        ▼
中/右两栏请求时附加 dataTime
  - Part.Middle.Settings.tsx:296 → getTownshipOutOfServicePhysicsApi({...requestParams, dataTime})
  - Part.Right.Table.tsx:22     → getTransmissionInterruptApi({...requestParams, dataTime})
```

> **时序含义**：
>
> - 三个表格共享同一时间点，避免"旗帜/汇总展示 T1 数据，而中/右仍展示 T0 数据"的不一致
> - 修改左栏数据源或新增表格时，**必须考虑是否纳入此同步链路**
> - `leftDataTime` 为 `null`（左栏未返回）时，中/右两栏会提前 `return Promise.resolve([])`，避免空数据时间漂移
> - 中/右两栏的 `ready: isDefined(params)` 还会再叠加一次"params 完整"判断

---

## 快速任务指南

### 修改弹窗某层级列配置

编辑 `environment.json` 的 `gd-emergency-support.modules.damage-to-towns.detailModal.{physical|logic}.columns.{zoneLevel}` 数组。
→ 列配置规范详见 [config-reference.md](./config-reference.md#单列配置完整字段)

### 修改三栏表格列

- **中栏**：编辑 `Part.Middle.Settings.tsx` 中 `useMiddleTable` 内的 `logicTable.columns` / `physicalTable.columns`
- **右栏**：编辑 `Part.Right.tsx` 的 `columns` 数组
- **左栏汇总表**：编辑 `Part.Left.Table.tsx` 中 `useLeftTable` 的初始 columns

### 调整轮询间隔

修改 `environment.json` 的 `gd-emergency-support.modules.damage-to-towns.request.interval`（单位秒）

### 修改弹窗下钻行为

`ExitServiceDetail.tsx` 的 `handleRowClick`（约 line 189），`record.zoneLevel === ZoneLevelEnum.city` 时终止下钻

### 修改 ServiceType 枚举

共享枚举 `ServiceType` 定义在 `Context.tsx` 中，`ExitServiceDetail` 和 `Part.Middle` 共用。值：`ServiceType.Physical = "physical"`、`ServiceType.Logical = "logical"`。

### 修改弹窗拖拽行为

`index.tsx` 中 `state.disabledDraggable` 控制；`ExitServiceDetail` 顶部条 `onMouseOver/onMouseOut` 切换

### 修改 GIS 打点参数

`index.tsx` 的 `onCellClick` 中构建 params 对象，通过 `dispatch(widgetFields.getField("sectionRight:damageToTownsGisPin"), params)` 派发

---

## 拓展场景指南

以下为最常见的 6 类拓展场景，每类均给出"修改位置 + 关键代码片段 + 验证步骤"。

### 场景 1：新增一种告警颜色 / 等级

**触发**：业务方要求把"紫色"作为新的"乡镇单断"等级，与现有蓝/黄/红并列。

**修改清单**（共 4 处必须同步）：

1. `Context.tsx:17-21` —— 在 `ColorLevelString` 枚举中追加：

```typescript
enum ColorLevelString {
    Red = "red",
    Yellow = "yellow",
    Blue = "blue",
    Purple = "purple", // 新增
}
```

2. `Context.tsx:23-27` —— 在 `AlarmLevelString` 中追加映射（**否则右栏过滤失效**）：

```typescript
const AlarmLevelString = {
    [ColorLevelString.Red]: "乡镇全阻",
    [ColorLevelString.Yellow]: "乡镇双断",
    [ColorLevelString.Blue]: "乡镇单断",
    [ColorLevelString.Purple]: "乡镇预警", // 新增
};
```

3. `Part.Left.tsx:14` —— `IconFlagImages` 数组追加第 4 个图标：

```typescript
const IconFlagImages = [iconFlagBlue, iconFlagYellow, iconFlagRed, iconFlagPurple];
```

4. `index.css` —— 在 `.item:nth-child(N)` 规则中追加颜色变量（参照现有蓝/黄/红规则）

5. `Part.Right.tsx:33-37` —— `colors` 对象追加（如果右栏需要展示新等级）：

```typescript
const colors = {
    乡镇单断: "rgb(22, 223, 241)",
    乡镇双断: "rgb(246, 191, 40)",
    乡镇全阻: "rgb(241, 57, 57)",
    乡镇预警: "rgb(180, 100, 220)", // 新增
} as any;
```

6. `index.tsx:35-44` —— 标题栏 Tooltip 追加新等级图例

**验证步骤**：

- 点击紫色旗帜 → 中栏按 `severity === 'purple'` 过滤，右栏按 `alarmType === '乡镇预警'` 过滤
- 弹窗外 tooltip 显示 4 个色块
- 控制台无 warning

### 场景 2：新增一列到中栏物理退服表

**修改清单**（1 处）：

`Part.Middle.Settings.tsx` 的 `physicalTable.columns` 数组追加：

```typescript
{
    title: "新指标",
    dataIndex: "newField",
    align: "center",
    width: 100,
    render: (_unUse: any, record: any) => {
        return <span>{record.newField}</span>;
    },
}
```

**验证步骤**：

- 表格宽度不溢出（CSS `.middle { width: 601px }` 可能需要调整）
- 排序/筛选/选中行不受影响
- mock 数据可缺 `newField`（render 函数内做 `record.newField ?? "-"` 兜底）

### 场景 3：把 Mock 数据切到真实 API

**修改清单**（1 处 × 6 接口）：

`apps/main/request/right.ts` 每个接口的 `getViewItemDataApi` 调用中：

```typescript
// 修改前
localMockUrl: "/static/mock/emergency/xxx.json",

// 修改后：直接删除或留空（项目内 request 工具会自动 fallback 到真实 API）
localMockUrl: "",
```

**注意**：

- 不要删除 `viewItemId` 和 `viewPageId`，它们是后端定位数据的标识
- 真实接口可能要求额外的 `viewPageArgs` 字段（按后端约定补齐）
- 切换后需要在 `environment.json` 中确认 `baseUrlType`（默认 `sceneViewService`）

### 场景 4：新增弹窗下钻层级

**当前支持**：province → region → city → town（4 级）

**如需新增第 5 级**（如 村/网格），需要修改：

1. `Context.tsx` —— 在 `ZoneLevelEnum` 中追加值
2. `ExitServiceDetail.tsx:66-85` —— `buildRequestParams()` switch 中追加 case
3. `ExitServiceDetail.tsx:191` —— `handleRowClick` 中调整终止条件
4. `environment.json` —— 在 `detailModal.{physical|logic}.columns` 中追加对应的 `zoneLevel` 配置项
5. `api-reference.md` —— 在 `getTownshipOutOfServiceCountPhysicsApi` 响应结构中追加村/网格字段

### 场景 5：新增 GIS 派发字段

**触发**：GIS 接收方需要新增一个字段（如 `provinceName`）。

**修改清单**（1 处）：

`index.tsx:116-133` 的 `params` 对象中追加：

```typescript
const params = {
    // ... 现有字段
    provinceName: "广东省", // 新增
};
```

**注意**：

- 必须在三表（middleTable / rightTable / exitServiceDetailModal）共用同一字段，避免 GIS 接收方按表分支处理
- 修改后通知 GIS 接收方更新字段约定
- 在 `SKILL.md` 关键交互机制详解 § 1 中同步更新字段对照表

### 场景 6：调整弹窗拖拽行为

**修改清单**（2 处）：

1. `index.tsx:80-83` —— `disabledDraggable` 默认值
2. `index.tsx:196-201` —— `onMouseOver` / `onMouseOut` 触发区域

如要新增一个"非拖拽但可点击"的子区域，需要在 `ExitServiceDetail.tsx` 包裹外层 div 并拦截冒泡。

---

## 常见问题排查

### Q1：旗帜点击后中/右两栏没反应

**可能原因**：

1. `Context.tsx:AlarmLevelString` 未同步新颜色 → 查 `Part.Right.tsx:82` 过滤逻辑
2. `leftSelectedFlag` 已激活但点击同一旗帜会重置为 `null`（确认是否在重复点击）
3. 中/右两栏数据本身就为空，过滤后自然无数据

**排查命令**：

```typescript
// 在浏览器 console 临时注入
console.log("leftFlag:", document.querySelector(".ind-icon-flag-blue").parentElement.classList);
```

### Q2：表格一直 loading 不显示

**可能原因**：

1. `currentRegionParams.requestParams` 为 `null`（未选中区域）→ 中/右两栏 `ready: false`
2. `leftDataTime` 为 `null` → 中/右两栏提前 `return Promise.resolve([])`
3. API 接口 500 错误 → 查看 Network 面板的 `viewItemId` 请求

**排查步骤**：

- 打开 Network 面板，过滤 `viewItemId`，确认 6 个接口都返回 200
- 检查 `dataTime` 字段是否在 `dataSource[0]` 中存在

### Q3：弹窗打不开 / 打开后无数据

**可能原因**：

1. `state.openDetailModal` 未被设置为 `true`（点击"退服统计"按钮的事件绑定）
2. `StyledDraggableModal` 的 `getContainer` 未指向正确 DOM 节点
3. 弹窗内 API 的 `zoneLevel` 在 `environment.json` 中无对应列配置 → `columnsSetting` 为 `undefined`

**排查步骤**：

- 检查 `index.tsx:181-205` 的 `StyledModal` 渲染条件
- 检查 `ExitServiceDetail.tsx:101-103` 的 `getEnvironment` 路径是否拼写正确

### Q4：GIS 打点派发后地图无反应

**可能原因**：

1. `widgetFields.getField("sectionRight:damageToTownsGisPin")` 未在 `fields/index.ts` 中注册
2. GIS 接收方未订阅该字段
3. `params.zoneLevel` 不是 `"3"`（与 GIS 约定不符）

**排查步骤**：

- 临时在 `index.tsx:144` 加 `console.log("[GIS]", params)` 确认派发
- 与 GIS 同事对齐 `sectionRight:damageToTownsGisPin` 字段名

### Q5：dataTime 显示 T0 但表格展示 T1 数据

**这是已知设计**：

- `leftDataTime` 控制中/右两栏的 `dataTime` 参数
- 中/右两栏返回的 `dataTime` 来自 `rows[0]?.scanTime`，可能比 `leftDataTime` 晚一拍
- **如果业务要求严格一致**，需要在 `Context.tsx:144` 处把 `leftDataTime` 强行作为中/右两栏的展示时间

### Q6：新增的列在弹窗内不显示

**可能原因**：

1. `environment.json` 中该 `zoneLevel` 层级未配置该列
2. `dataIndex` 拼写错误
3. 后端 mock 数据缺该字段

**排查命令**：

```javascript
// 在浏览器 console
const env = await fetch("/config/environment.json").then((r) => r.json());
console.log(env["gd-emergency-support"].modules["damage-to-towns"].detailModal.physical.columns["4"]);
```

### Q7：拖拽失效或异常拖动

**可能原因**：

1. 鼠标未在"顶部数据时间 + 按钮区域"内 → 不会触发 `onMouseOver`
2. `getContainer` 返回 `null` 或非 `body` 父级
3. 弹窗 `destroyOnHidden` 重建后状态丢失

**排查步骤**：

- 确认鼠标在弹窗顶部条区域内
- 检查 `index.tsx:186` 的 `getContainer` 回调

---

## 详细参考文档

- [API 参考文档](./api-reference.md) — 6 个接口的请求参数、响应结构、Mock 路径、viewItemId
- [环境配置参考文档](./config-reference.md) — 配置树、列配置规范、zoneLevel 映射、列配置示例
- [ExitServiceDetail 弹窗详解](./exit-service-detail.md) — 按钮组、下钻参数构建、行点击控制、拖拽控制

---

## 依赖

- React + TypeScript + Next.js
- antd（Table、ConfigProvider、Tooltip、Button）
- ahooks（useSetState、useRequest、useMemoizedFn、useLatest）
- dayjs、lodash-es
- 项目内部：StyledTable、StyledDraggableModal、Box、widgetFields、useDispatch/useSubscribe、ZoneLevelEnum
- 工具函数：getEnvironment、useEnvironment、formatString、cx、isDefined
- 接口：均来自 `@/request/right`

---

## 版本信息

| 字段           | 值                                                                                             |
| -------------- | ---------------------------------------------------------------------------------------------- |
| **Skill ID**   | `gd-es-next-right-damage-to-towns`                                                             |
| **当前版本**   | `1.1.0`                                                                                        |
| **最后更新**   | `2026-06-16`                                                                                   |
| **维护者**     | Emergency Support Team                                                                         |
| **适用项目**   | `oss-visual-gd-emergency-support-next`                                                         |
| **包管理器**   | pnpm（workspace 根目录执行）                                                                   |
| **入口模块**   | `apps/main/app/components/right/network-compact/damage-to-towns/index.tsx`                     |
| **接口文件**   | `apps/main/request/right.ts`（6 个 viewItemId）                                                |
| **配置文件**   | `apps/main/public/config/environment.json`（`gd-emergency-support.modules.damage-to-towns.*`） |
| **关联 Skill** | `damage-to-towns-exit-service-detail`（弹窗子模块）                                            |

## 版本历史

| 版本    | 日期         | 变更摘要                                                                                                                                                                                                                  |
| ------- | ------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `1.1.0` | `2026-06-16` | 新增「关键交互机制详解」4 小节：`onCellClick` 三表 payload 差异表、旗帜过滤双映射规则、`currentRegionParams` 回退规则、`dataTime` 同步链路；新增「拓展场景指南」与「常见问题排查」章节；补充 frontmatter 元数据与版本章节 |
| `1.0.0` | `2026-06-02` | 初版发布：覆盖 10 个源文件、6 个 API、3 个参考文档；建立 Left/Middle/Right + 弹窗架构、轮询、拖拽、GIS 派发、配置规范的完整维护指引                                                                                       |

## 适用范围

- ✅ **适用**：新增/修改三栏表格列、调整轮询间隔、配置弹窗列、调整下钻行为、修改 ServiceType 枚举、调整拖拽行为、修改 GIS 派发参数
- ✅ **适用**：接入新数据源（替换 mock）、新增/调整颜色枚举、新增旗帜（**必须同步** `Context.tsx:AlarmLevelString`）
- ✅ **适用**：6 类常见拓展场景——新增颜色等级、新增列、切真实 API、新增下钻层级、新增 GIS 字段、调整拖拽（详见「拓展场景指南」）
- ✅ **适用**：7 类常见故障排查——旗帜无反应、loading 卡死、弹窗异常、GIS 无响应、dataTime 不一致、新列不显示、拖拽失效（详见「常见问题排查」）
- ⚠️ **谨慎**：修改 `onCellClick` 字段、修改 `currentRegionParams` 回退逻辑、修改 `dataTime` 同步链路（牵涉面广，需评估对 GIS 接收方与中/右两栏的影响）
- ❌ **不适用**：跨模块修改（如网络规模、左屏应急资源）、纯样式/响应式调整（建议在 `index.css` 内处理）
